<?php
$user = "id20209243_adminsem";
$password = "Qh6I!x@V0coCN~fp";
$host = "localhost";
$database = "id20209243_sembradiodos";

try {
	$conexion = new PDO("mysql:host=" . $host . ";dbname=" . $database, $user, $password);
	$conexion->exec("SET CHARACTER SET utf8");
	echo "CONECTO </br>";
} catch (PDOException $e) {
	echo "ERROR AL CONECTAR CON LA BASE DE DATOS " . $e->getMessage() . '</br>';
}


// $user = "root";
// $password = "";
// $host = "localhost";
// $database = "sembradiodos";

// try {
// 	$conexion = new PDO("mysql:host=" . $host . ";dbname=" . $database, $user, $password);
// 	$conexion->exec("SET CHARACTER SET utf8");
// 	echo "CONECTO </br>";
// } catch (PDOException $e) {
// 	echo "ERROR AL CONECTAR CON LA BASE DE DATOS " . $e->getMessage() . '</br>';
// }
