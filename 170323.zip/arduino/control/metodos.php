<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require_once("../control/conexion.php");
require 'vendor/autoload.php';
class Metodos
{
    public function verificarRango(PDO $conexion, $datos, $opcion, $valor, $opc, $id_cultivo, $mail)
    {
        try {
            $consulta = "SELECT EXTRACT(DAY FROM (now())) - EXTRACT(DAY FROM (fecha_ingreso)) as dias_pasados, plantula_fija
            FROM cama
                     INNER JOIN semilla s on cama.id_semilla = s.id_semilla
            WHERE id_cama = :idcama";

            $stmt = $conexion->prepare($consulta);
            $stmt->bindParam(":idcama", $id_cultivo);

            $stmt->execute();
            $count = $stmt->rowCount();


            $fecha = $stmt->fetch();
            echo '</br> ------------------------------------------------------------------------------------------------- </br>';
            $limites = explode('-', $datos['' . $opcion]);
            echo 'VALOR: ' . $valor . ' </br>';
            echo 'inf: ' . $limites[1] . '</br>';
            echo 'sup: ' . $limites[0] . '</br>';

            if ($valor >= $limites[1] && $valor <= $limites[0]) {
                echo $opcion . ' EN RANGO:) </br>';
                $sql = "UPDATE cama SET $opc = :opc WHERE id_cama = :idcultivo";
                $stmt = $conexion->prepare($sql);
                $stmt->bindParam(":opc", $valor);
                $stmt->bindParam(":idcultivo", $id_cultivo);

                if ($stmt->execute()) {
                    echo "SE ACTUALIZO $opcion </br>";
                } else {
                    echo "NO SE ACTUALIZO $opcion </br>";
                }
            } else {
                echo $opcion . ' FUERA DE RANGO:( </br>';
                $sql = "UPDATE cama SET $opc = :opc WHERE id_cama = :idcultivo";
                $stmt = $conexion->prepare($sql);
                $stmt->bindParam(":opc", $valor);
                $stmt->bindParam(":idcultivo", $id_cultivo);

                if ($stmt->execute()) {
                    echo "SE ACTUALIZO $opcion </br>";
                } else {
                    echo "NO SE ACTUALIZO $opcion </br>";
                }

                $mail->setFrom('sembradiocona@gmail.com', 'REVISE: ' . $opc);
                //$mail->addAddress('jesus.salinas.le.9@gmail.com', 'JESUS');
                $mail->addAddress('jairreyes689@gmail.com', 'JAIR');
                $mail->isHTML(true);
                $mail->Subject = $opcion . ' fuera de rango';
                $mail->Body = 'Revisar ' . $opcion . '  de la cama ' . $datos['cama'] . ' </br> en el ' . $datos['nombre_inver'] .
                    ' </br> Dirección: ' . $datos['direccion'];
                $mail->send();
                echo 'CORREO ENVIADO </br>';
            }


            // PLANTULA COMPLETA

            if ($fecha['dias_pasados'] > $fecha['plantula_fija']) {

                $mail->setFrom('sembradiocona@gmail.com', 'PLANTULA COMPLETA');
                //$mail->addAddress('jesus.salinas.le.9@gmail.com', 'JESUS');
                $mail->addAddress('jairreyes689@gmail.com', 'JAIR');

                $mail->isHTML(true);
                $mail->Subject = 'En la cama: ' . $datos['cama'];
                $mail->Body = 'Los dias fijos para la semilla' . $datos['nombre_semilla'] . ', ya pasaron su limite por favor revisarlo, es la cama ' . $id_cultivo . ', con nombre: ' . $datos['cama'] . ', esta en el invernadero: ' . $datos['nombre_inver']
                    . '</br> En la direccion: ' . $datos['direccion'];
                $mail->send();
                echo 'CORREO ENVIADO </br>';
            }
        } catch (Exception $e) {
            echo 'MENSAJE ERROR: ' . $mail->ErrorInfo . '  </br>';
        }
    }
}
