<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require_once("conexion.php");
require_once("metodos.php");
require 'vendor/autoload.php';

try {
    $metodo = new Metodos();

    //CONFIGURACIÓN PARA ENVIAR CORREO
    $mail = new PHPMailer(true);
    //$mail->SMTPDebug = SMTP::DEBUG_SERVER;
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'sembradiocona@gmail.com';
    $mail->Password = 'tgrsnkndomrpaozx';
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
    $mail->Port = 465;


    //id_invernadero=1&id_cama=1&temp=16&hum=5.5&phagua=1.5&phtierra=20
    if (!empty($_POST["id_invernadero"]) && !empty($_POST["id_cama"]) && !empty($_POST["phagua_temp"]) && !empty($_POST["phagua_hum"]) && !empty($_POST["phagua"]) && !empty($_POST["phtierra"]) && !empty($_POST["phtierra_hum"])) {
        $id_invernadero = $_POST["id_invernadero"];
        $id_cama = $_POST["id_cama"];
        $temp = $_POST["phagua_temp"];
        $hum = $_POST["phagua_hum"];
        $phagua = $_POST["phagua"];
        $phtierra = $_POST["phtierra"];
        $phtierra_hum = $_POST["phtierra_hum"];

        echo ' ID_INVERNADERO GET: ' . $id_invernadero . '</br>';
        echo ' ID_CAMA GET: ' . $id_cama . '</br>';
        echo ' TEMP GET: ' . $temp . '</br>';
        echo ' HUM GET: ' . $hum . '</br>';
        echo ' PHAGUA GET: ' . $phagua . '</br>';
        echo ' PHTIERRA GET: ' . $phtierra . '</br>';
        echo ' PHTIERRA HUM GET: ' . $phtierra_hum . '</br>';

        $sqlinfo = "SELECT  ca.id_cama as id_cama,
                            ca.cama as cama,
                            CONCAT(d.calle,' ,ext: #',d.numero_ext,', int: #',d.numero_int,', ',l.localidad,', ',m.municipio,', ',e.estado) as direccion,
                            i.nombre as nombre_inver,
                            s.id_semilla as id_semilla,
                            s.nombre as nombre_semilla,
                            s.agua_fija as agua_fija,
                            s.tierra_fija as tierra_fija,
                            s.agua_humedad_fija as agua_humedad_fija,
                            s.agua_temperatura_fija,
                            s.plantula_fija,
                            s.tierra_humedad_fija,
                            ca.fecha_ingreso,
                            s.plantula_fija
                    FROM cama ca
                            INNER JOIN semilla s on ca.id_semilla = s.id_semilla
                            INNER JOIN invernadero i on ca.id_invernadero = i.id_invernadero
                            INNER JOIN direccion d on i.id_direccion = d.id_direccion
                            INNER JOIN localidad l on d.id_localidad = l.id_localidad
                            INNER JOIN municipio m on l.id_municipio = m.id_municipio
                            INNER JOIN estado e on m.id_estado = e.id_estado
                    WHERE i.id_invernadero = :idinver
                    AND ca.id_cama = :idcama";

        $stmt = $conexion->prepare($sqlinfo);
        $stmt->bindParam(":idinver", $id_invernadero);
        $stmt->bindParam(":idcama", $id_cama);
        $stmt->execute();
        $count = $stmt->rowCount();

        if ($count > 0) {
            $datos = $stmt->fetch();
            $id_cultivo =  $datos['id_cama'];
            // PDO $conexion, $datos, $opcion, $valor, $opc, $id_cultivo, $mail
            $metodo->verificarRango($conexion, $datos, 'agua_fija', $phagua, 'phagua', $id_cultivo, $mail);
            $metodo->verificarRango($conexion, $datos, 'agua_temperatura_fija', $temp, 'phagua_temperatura', $id_cultivo, $mail);
            $metodo->verificarRango($conexion, $datos, 'agua_humedad_fija', $hum, 'phagua_humedad', $id_cultivo, $mail);
            $metodo->verificarRango($conexion, $datos, 'tierra_fija', $phtierra, 'phtierra', $id_cultivo, $mail);
            $metodo->verificarRango($conexion, $datos, 'tierra_humedad_fija', $phtierra_hum, 'phtierra_humedad', $id_cultivo, $mail);
        } else {
            echo 'NO DATOS';
        }
    } else {
        echo 'Parametros vacios  </br>';
    }
} catch (Exception $e) {
    echo 'MENSAJE ERROR: ' . $mail->ErrorInfo . '  </br>';
}
