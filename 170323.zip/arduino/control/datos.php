<?php
class Herramienta
{
	private $conexion;

	function __construct()
	{
		require_once("conexion.php");
		$this->conexion = new conexion();
		$this->conexion->conectar();
	}

	public function ingresar_datos($id_familia, $nombre, $diasSiembra, $diaPlantula, $diaCosecha, $descripcion)
	{
		// $id_familia = '1';
		// $nombre = '2';
		// $diasSiembra = '3';
		// $diaPlantula = '4';
		// $diaCosecha = '5';
		// $descripcion = '6';

		$sql = "INSERT INTO prueba.familias (id_familia,nombre,diasSiembra,diaPlantula,diaCosecha,descripcion) 
		VALUES (?,?,?,?,?,?)";
		$stmt = $this->conexion->conexion->prepare($sql);

		$stmt->bindValue(1, $id_familia);
		$stmt->bindValue(2, $nombre);
		$stmt->bindValue(3, $diasSiembra);
		$stmt->bindValue(4, $diaPlantula);
		$stmt->bindValue(5, $diaCosecha);
		$stmt->bindValue(6, $descripcion);

		if ($stmt->execute()) {
			echo "Ingreso Exitoso";
			// echo $_GET['id_familia'];
			// echo $_GET['nombre'];
			// echo $_GET['diasSiembra'];
			// echo $_GET['diaPlantula'];
			// echo $_GET['diaCosecha'];
			// echo $_GET['descripcion'];
		} else {
			echo "no se pudo registrar datos";
		}
	}
}
