    <?php
    require_once("./conexion/conexion.php");



    if (isset($_POST['fecha_ingreso']) && isset($_POST['semilla']) && isset($_POST['nombre_cama']) && isset($_POST['cama']) && isset($_POST['invernadero']) && $_POST['invernadero'] > 0 && $_POST['cama'] > 0 && !empty($_POST['nombre_cama'])) {
        $id_cama = $_POST['cama'];
        $semilla = $_POST['semilla'];
        $fecha = $_POST['fecha_ingreso'];
        $cosecha = $_POST['fecha_cosecha'];
        $plantula = $_POST['fecha_plantula'];
        $nombre_cama = $_POST['nombre_cama'];

        if (mysqli_query($conexion, "UPDATE cama set cama = '$nombre_cama', 
                                                     id_semilla = $semilla, 
                                                     fecha_ingreso = '$fecha',
                                                     fecha_cosecha = '$cosecha',
                                                     fecha_plantula = '$plantula'
                                                WHERE id_cama = $id_cama")) {
            echo '<script> window.location.assign("./camas.php?nav=CA&res=S"); </script>';
        } else {
            echo '<script> window.location.assign("./camas.php?nav=CA&res=err"); </script>';
        }
    } else {
        echo '<script> window.location.assign("./camas.php?nav=CA&res=i"); </script>';
    }
